package org.flytomarchik.autosprint.sprint;

import net.minecraft.class_1657;
import net.minecraft.class_310;
import org.flytomarchik.autosprint.config.ConfigManager;

public class WaterSprint extends BaseSprint {

    @Override
    public boolean canSprint(class_310 client, ConfigManager.Config config) {
        // Модуль работает, только если разрешен в конфиге
        if (!config.allowInWater) return false;

        class_1657 player = client.field_1724;
        if (player == null) return false;

        // Проверка, находится ли игрок в воде
        return player.method_5799() || player.method_5869();
    }

    public boolean isInWater(class_310 client) {
        var player = client.field_1724;
        return player != null && (player.method_5799() || player.method_5869());
    }
}