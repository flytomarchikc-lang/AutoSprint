package org.flytomarchik.autosprint.sprint;

import net.minecraft.class_310;
import org.flytomarchik.autosprint.config.ConfigManager;

public class FlySprint extends BaseSprint {
    @Override
    public boolean canSprint(class_310 client, ConfigManager.Config config) {
        // Работает только если модуль включен
        if (!config.flySprint) return false;

        var player = client.field_1724;
        if (player == null) return false;

        // Работает только в креативе, только в полете, и только при движении вперед
        // В Minecraft 1.21+ input.forward - это boolean
        return player.method_31549().field_7477 && player.method_31549().field_7479 && player.field_3913.method_20622();
    }
}