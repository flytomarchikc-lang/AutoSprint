package org.flytomarchik.autosprint.sprint;

import net.minecraft.class_310;
import org.flytomarchik.autosprint.config.ConfigManager;

public class ToggleSprint extends BaseSprint {

    @Override
    public boolean canSprint(class_310 client, ConfigManager.Config config) {
        // canSprintBasic и другие проверки остаются
        if (!canSprintBasic(client, config)) return false;

        var player = client.field_1724;
        if (player == null) return false;

        // ИСПРАВЛЕНИЕ БАГА С ВОДОЙ:
        // Если игрок в воде, обычный спринт отключается. Управление переходит к WaterSprint (если он включен).
        if (player.method_5799() || player.method_5869()) return false;

        // Отключаем обычный спринт, если игрок в полете (за это отвечает FlySprint)
        if (player.method_31549().field_7479) return false;

        // В Minecraft 1.21+ input.forward - это boolean
        return player.field_3913.method_20622();
    }
}