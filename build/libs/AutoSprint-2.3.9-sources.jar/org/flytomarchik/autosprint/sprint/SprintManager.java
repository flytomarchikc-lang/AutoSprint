package org.flytomarchik.autosprint.sprint;

import net.minecraft.class_310;
import org.flytomarchik.autosprint.config.ConfigManager;

public class SprintManager {
    private final ConfigManager configManager;
    private final ToggleSprint toggleSprint;
    private final WaterSprint waterSprint;
    private final FlySprint flySprint;

    // Флаг для отслеживания состояния в прошлом тике
    private boolean wasSprintingLastTick = false;

    public SprintManager(ConfigManager configManager) {
        this.configManager = configManager;
        this.toggleSprint = new ToggleSprint();
        this.waterSprint = new WaterSprint();
        this.flySprint = new FlySprint();
    }

    public void tick(class_310 client) {
        if (client.field_1724 == null) return;

        ConfigManager.Config config = configManager.getConfig();

        // 1. Глобальный выключатель
        if (!config.masterToggle) {
            if (wasSprintingLastTick) {
                // ИСПРАВЛЕНИЕ: Если выключили мастер-свитч во время бега, принудительно стопаем
                client.field_1690.field_1867.method_23481(false);
                client.field_1724.method_5728(false);
                wasSprintingLastTick = false;
            }
            return;
        }

        boolean shouldSprint = false;

        // 2. Логика приоритетов (Fly -> Water -> Standard)

        // --- FLY SPRINT ---
        if (client.field_1724.method_31549().field_7477 && client.field_1724.method_31549().field_7479) {
            if (flySprint.canSprint(client, config)) {
                shouldSprint = true;
            } else if (wasSprintingLastTick) {
                // БАГ ФИКС: Летим, но FlySprint выключен -> стоп
                client.field_1724.method_5728(false);
            }
        }
        // --- WATER SPRINT ---
        else if (client.field_1724.method_5799() || client.field_1724.method_5869()) {
            if (waterSprint.canSprint(client, config)) {
                shouldSprint = true;
            } else if (wasSprintingLastTick) {
                // БАГ ФИКС: В воде, но WaterSprint выключен -> стоп
                client.field_1724.method_5728(false);
            }
        }
        // --- STANDARD SPRINT ---
        else {
            BaseSprint currentMode = getCurrentSprintMode();
            if (currentMode != null && currentMode.canSprint(client, config)) {
                shouldSprint = true;
            }
        }

        // Применяем состояние
        client.field_1690.field_1867.method_23481(shouldSprint);
        wasSprintingLastTick = shouldSprint;
    }

    private BaseSprint getCurrentSprintMode() {
        return toggleSprint;
    }

    public void toggleMaster() {
        ConfigManager.Config config = configManager.getConfig();
        config.masterToggle = !config.masterToggle;
        configManager.save();
    }

    public void toggleWater() {
        ConfigManager.Config config = configManager.getConfig();
        config.allowInWater = !config.allowInWater;
        configManager.save();
    }

    public void toggleFly() {
        ConfigManager.Config config = configManager.getConfig();
        config.flySprint = !config.flySprint;
        configManager.save();
    }

    public boolean isEnabled() {
        return configManager.getConfig().masterToggle;
    }
}