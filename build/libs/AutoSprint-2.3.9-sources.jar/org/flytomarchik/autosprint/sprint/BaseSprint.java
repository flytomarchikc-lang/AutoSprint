package org.flytomarchik.autosprint.sprint;

import net.minecraft.class_310;
import org.flytomarchik.autosprint.config.ConfigManager;

public abstract class BaseSprint {
    protected boolean canSprintBasic(class_310 client, ConfigManager.Config config) {
        var player = client.field_1724;
        if (player == null) return false;

        if (player.method_7344().method_7586() <= 6 && !player.method_31549().field_7478) {
            return false;
        }

        if (player.field_5976 && !player.method_31549().field_7478) {
            return false;
        }

        if (player.method_5715() && !config.allowWhileSneaking) {
            return false;
        }

        // ИСПРАВЛЕНИЕ БАГА: Проверяем воду только если персонаж действительно плывет
        // А не просто находится в воде (например, прыгает над водой)
        if (player.method_5681() && !config.allowInWater) {
            return false;
        }

        return true;
    }

    public abstract boolean canSprint(class_310 client, ConfigManager.Config config);
}