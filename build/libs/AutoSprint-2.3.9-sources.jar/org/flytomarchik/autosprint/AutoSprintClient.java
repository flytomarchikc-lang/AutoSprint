package org.flytomarchik.autosprint;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.class_124;
import net.minecraft.class_2561;
import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3675;
import org.flytomarchik.autosprint.config.ConfigManager;
import org.flytomarchik.autosprint.gui.AutoSprintScreen;
import org.flytomarchik.autosprint.sprint.*;
import org.flytomarchik.autosprint.theme.ThemeManager;
import org.flytomarchik.autosprint.translation.TranslationManager;
import org.lwjgl.glfw.GLFW;

public class AutoSprintClient implements ClientModInitializer {

    public static class_304 masterKey;
    public static class_304 configKey;
    public static class_304 waterKey;
    public static class_304 flyKey;
    public static class_304 blurKey;
    public static class_304 resetGuiKey;

    private static SprintManager sprintManager;
    private static ConfigManager configManager;
    private static ThemeManager themeManager;
    private static TranslationManager translationManager;

    public static ThemeManager getThemeManager() {
        return themeManager;
    }

    public static TranslationManager getTranslationManager() {
        return translationManager;
    }

    public static ConfigManager getConfigManager() {
        return configManager;
    }

    public static SprintManager getSprintManager() {
        return sprintManager;
    }

    @Override
    public void onInitializeClient() {
        translationManager = new TranslationManager();
        configManager = new ConfigManager();
        themeManager = new ThemeManager();
        sprintManager = new SprintManager(configManager);
        configManager.load();

        themeManager.setTheme(configManager.getConfig().theme);

        masterKey = registerKey("key.autosprint.toggle", GLFW.GLFW_KEY_H);
        configKey = registerKey("key.autosprint.config", GLFW.GLFW_KEY_G);
        waterKey = registerKey("gui.water_sprint", GLFW.GLFW_KEY_UNKNOWN);
        flyKey = registerKey("gui.fly_sprint", GLFW.GLFW_KEY_UNKNOWN);
        blurKey = registerKey("key.autosprint.blur", GLFW.GLFW_KEY_UNKNOWN);
        resetGuiKey = registerKey("key.autosprint.reset", GLFW.GLFW_KEY_UNKNOWN);

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (masterKey.method_1436()) {
                sprintManager.toggleMaster();
                playSound(client, configManager.getConfig().masterToggle);
                sendNotification(client, "gui.master_switch", configManager.getConfig().masterToggle);
            }
            if (waterKey.method_1436()) {
                sprintManager.toggleWater();
                playSound(client, configManager.getConfig().allowInWater);
                sendNotification(client, "gui.water_sprint", configManager.getConfig().allowInWater);
            }
            if (flyKey.method_1436()) {
                sprintManager.toggleFly();
                playSound(client, configManager.getConfig().flySprint);
                sendNotification(client, "gui.fly_sprint", configManager.getConfig().flySprint);
            }
            if (blurKey.method_1436()) {
                boolean newState = !configManager.getConfig().useBlur;
                configManager.getConfig().useBlur = newState;
                configManager.save();
                playSound(client, newState);
                sendNotification(client, "Blur Effect", newState);
            }
            if (resetGuiKey.method_1436()) {
                resetGuiPositions();
                playSound(client, true);
                if (client.field_1724 != null) {
                    client.field_1724.method_7353(class_2561.method_43470("§8[§bAutoSprint§8] §7GUI Positions reset."), true);
                }
            }
            if (configKey.method_1436()) {
                if (client.field_1724 != null && client.field_1755 == null) {
                    client.method_1507(new AutoSprintScreen(null, configManager, themeManager, translationManager));
                }
            }
            sprintManager.tick(client);
        });
    }

    private class_304 registerKey(String name, int code) {
        return KeyBindingHelper.registerKeyBinding(new class_304(name, class_3675.class_307.field_1668, code, "category.autosprint"));
    }

    private void playSound(class_310 client, boolean enabled) {
        if (client.field_1724 == null || client.field_1687 == null) return;
        float pitch = enabled ? 1.5f : 0.8f;
        // ИСПРАВЛЕНО: Добавлен аргумент client.player (источник) и убран boolean в конце
        client.field_1687.method_43128(client.field_1724, client.field_1724.method_23317(), client.field_1724.method_23318(), client.field_1724.method_23321(),
                class_3417.field_14622.comp_349(), class_3419.field_15248, 1.0f, pitch);
    }

    private void sendNotification(class_310 client, String keyName, boolean state) {
        if (client.field_1724 == null) return;
        String name = translationManager.get(keyName);

        class_2561 status = class_2561.method_43470(state ? " ✔ ENABLED" : " ❌ DISABLED")
                .method_27694(style -> style
                        .method_10977(state ? class_124.field_1060 : class_124.field_1061)
                        .method_10982(true));

        class_2561 prefix = class_2561.method_43470("AutoSprint » ").method_27694(style -> style.method_10977(class_124.field_1075).method_10982(true));
        class_2561 module = class_2561.method_43470(name).method_27694(style -> style.method_10977(class_124.field_1080));

        client.field_1724.method_7353(prefix.method_27661().method_10852(module).method_10852(status), true);
    }

    private void resetGuiPositions() {
        var cfg = configManager.getConfig();
        cfg.panelThemeX = -1; cfg.panelThemeY = -1;
        cfg.panelMainX = -1; cfg.panelMainY = -1;
        cfg.panelConfigX = -1; cfg.panelConfigY = -1;
        configManager.save();
    }
}