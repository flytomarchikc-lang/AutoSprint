package org.flytomarchik.autosprint.gui.components;

import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_4587;
import org.flytomarchik.autosprint.config.ConfigManager;
import org.flytomarchik.autosprint.gui.RenderUtils;
import org.flytomarchik.autosprint.theme.ThemeManager;
import org.flytomarchik.autosprint.translation.TranslationManager;

public class SprintModeComponent implements UIComponent {
    private final ConfigManager.Config config;
    private final ConfigManager configManager;
    private final TranslationManager translationManager;

    public SprintModeComponent(ConfigManager.Config config, ConfigManager configManager, TranslationManager translationManager) {
        this.config = config;
        this.configManager = configManager;
        this.translationManager = translationManager;
    }

    @Override
    public int getHeight() { return 70; }

    @Override
    public void render(class_4587 matrices, class_332 context, int x, int y, int width, int mouseX, int mouseY, float delta, float pulse, ThemeManager.Theme theme, TranslationManager translationManager) {
        boolean hovered = isHovered(mouseX, mouseY, x, y, width, 70);
        int bgColor = hovered ? RenderUtils.setAlpha(theme.getAccent(), 30) : RenderUtils.setAlpha(0x000000, 40);
        RenderUtils.drawRoundedRect(matrices, x, y, width, 70, 10, bgColor);
        RenderUtils.drawRoundedRect(matrices, x + 4, y + 25, 3, 20, 1.5f, theme.getAccent());

        String icon = getModeIcon(config.sprintMode);
        context.method_51433(class_310.method_1551().field_1772, icon, x + 15, y + 15, theme.getAccent(), false);
        context.method_51433(class_310.method_1551().field_1772, translationManager.get("gui.sprint_mode"), x + 35, y + 10, 0xFFFFFFFF, false);

        String modeName = translationManager.get(getModeKey(config.sprintMode));
        context.method_51433(class_310.method_1551().field_1772, modeName, x + 35, y + 28, theme.getAccent(), false);

        String modeDesc = translationManager.get(getModeKey(config.sprintMode) + ".desc");
        context.method_51433(class_310.method_1551().field_1772, modeDesc, x + 35, y + 45, 0xFF999999, false);

        context.method_51433(class_310.method_1551().field_1772, "▶", x + width - 20, y + 30, 0xFF999999, false);
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int x, int y, int width) {
        if (isHovered(mouseX, mouseY, x, y, width, 70)) {
            ConfigManager.Config.SprintMode[] modes = ConfigManager.Config.SprintMode.values();
            int currentIndex = config.sprintMode.ordinal();
            config.sprintMode = modes[(currentIndex + 1) % modes.length];
            configManager.save();
            class_310.method_1551().method_1483().method_4873(net.minecraft.class_1109.method_47978(net.minecraft.class_3417.field_15015, 1.0F));
            return true;
        }
        return false;
    }

    private String getModeIcon(ConfigManager.Config.SprintMode mode) {
        switch (mode) {
            case FORWARD_ONLY: return "→";
            case OMNI_DIRECTIONAL: return "↔";
            case TOGGLE_SPRINT: return "⟲";
            case RAGE_SPRINT: return "⚡";
            default: return "→";
        }
    }

    private String getModeKey(ConfigManager.Config.SprintMode mode) {
        switch (mode) {
            case FORWARD_ONLY: return "mode.forward_only";
            case OMNI_DIRECTIONAL: return "mode.omni";
            case TOGGLE_SPRINT: return "mode.toggle";
            case RAGE_SPRINT: return "mode.rage";
            default: return "mode.toggle";
        }
    }
}