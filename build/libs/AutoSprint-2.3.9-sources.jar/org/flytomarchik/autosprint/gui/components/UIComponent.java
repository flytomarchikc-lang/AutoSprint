package org.flytomarchik.autosprint.gui.components;
import net.minecraft.class_332;
import net.minecraft.class_4587;
import org.flytomarchik.autosprint.theme.ThemeManager;
import org.flytomarchik.autosprint.translation.TranslationManager;
public interface UIComponent {
    void render(class_4587 matrices, class_332 context, int x, int y, int width, int mouseX, int mouseY, float delta, float pulse, ThemeManager.Theme theme, TranslationManager translationManager);
    boolean mouseClicked(double mouseX, double mouseY, int x, int y, int width);
    int getHeight();
    default boolean isHovered(double mouseX, double mouseY, int x, int y, int width, int height) {
        return mouseX >= x && mouseX <= x + width && mouseY >= y && mouseY <= y + height;
    }
    default int setAlpha(int color, int alpha) {
        return (alpha << 24) | (color & 0x00FFFFFF);
    }
}