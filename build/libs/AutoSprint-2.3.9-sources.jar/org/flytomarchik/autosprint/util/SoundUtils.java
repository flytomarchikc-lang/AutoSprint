package org.flytomarchik.autosprint.util;

import net.minecraft.class_310;
import net.minecraft.class_3417;
import net.minecraft.class_3419;

public class SoundUtils {
    public static void playToggle(boolean state) {
        class_310 mc = class_310.method_1551();
        if (mc.field_1724 == null) return;

        // Высокий тон для включения, низкий для выключения
        float pitch = state ? 1.2f : 0.8f;
        // Звук "pling" или "toast"
        mc.field_1687.method_43128(mc.field_1724, mc.field_1724.method_23317(), mc.field_1724.method_23318(), mc.field_1724.method_23321(),
                class_3417.field_14622.comp_349(), class_3419.field_15250, 0.5f, pitch);
    }

    public static void playClick() {
        class_310 mc = class_310.method_1551();
        if (mc.field_1724 != null) {
            mc.field_1724.method_5783(class_3417.field_15015.comp_349(), 0.3f, 1.0f);
        }
    }

    public static void playDelete() {
        class_310 mc = class_310.method_1551();
        if (mc.field_1724 != null) {
            mc.field_1724.method_5783(class_3417.field_15015.comp_349(), 0.3f, 0.6f);
        }
    }
}